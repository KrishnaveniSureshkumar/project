# Login-Form-in-Netbeans-with-MySQL
Designing a simple username, password and submit button JForm (Swing) in Netbean IDE 8.1 and connecting with MySQL.  If username and password found in table in Mysql, then login successful.
